function fIRST(a,t)  
close all;
x=a(:,1);
y=a(:,2);
z=a(:,3);
xyz=sqrt(x.^2+y.^2+z.^2);
mn=mean(xyz);
xyz=xyz-mn;
figure;plot(t,xyz);title('Accelerometer Data without DC offset + Peak Detected');
st=std(xyz);
[pks, loc]=findpeaks(xyz,'MINPEAKHEIGHT',st);
hold on;plot(t(loc),pks,'r*');hold off
figure;hist(xyz,50);title('Histogram For Data');

out=sgolayfilt(xyz,3,21);figure;plot(t,out);title('Filtered Data');
st1=std(out);
[pks1, loc1]=findpeaks(out,'MINPEAKHEIGHT',st1);
hold on;plot(t(loc1),pks1,'r*');hold off
2*size(pks1,1)